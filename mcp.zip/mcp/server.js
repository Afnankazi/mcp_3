import { Language } from "@google/genai";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { version } from "react";
import z from "zod";

const server = new  McpServer({
    name:"Afnan_mcp",
    version:"1.0.0",
    capabilities:{
        resource:{},
        tools:{},
        prompts:{}
    }

})

server.tool(
    "generate-code",
    "Generate code based on description",
    {
        description:z.string(),
        language:z.string().default("javascript"),
        framework: z.string().optional(),
        rootpath: z.string()
    },
    {
        title:"Code Generator",
        readonlyHint: false,
        destructiveHint:false,
        idempotentHint:false,
        openWorldHint:true
    },
    async (params) =>{
        try {
            const data = "test function";
            return{
                content:[
                    {type : "text" , text: JSON.stringify(data)}
                ]
            }
        } catch (error) {
             return{
                content:[
                    {type : "text" , text: JSON.stringify(error)}
                ]
            }
            
        }
    }

)

async function main() {

    const transport = new StdioServerTransport();
    await server.connect(transport);
    
}